;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;


THANK YOU FOR DOWNLOADING
	SCRAP DIARY

>> PLEASE NOTE:
>> THIS GAME AUTOSAVES WHEN RETURNING TO THE OVERWORLD 


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;


SCRAP DIARY WAS CREATED BY
	LAZY and LOLYOSHI
	
WITH SOME HELP FROM
	GBREEZESUNSET
		and
	MARKYJOE1990.
(more details below)


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

	
THANK YOU TO
	CARDBOARDCELL,
	GBREEZE,
	LOUISDOUCET,
	MIRACLEWATER,
	SIXCORBY,
	REXTEP and WYATT
FOR TESTING.


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;


	MADE WITH ASM BY
Romi
Kevin
Jackthespades
Mattrizzle
mikeyk
yoshicookiezeus
Akaginite
Lui
Tsutarja
Ice Man
Sonikku
Fierce Deity Manuz OW Hacker
Arinsu
ghettoyouth
SMWEdit
LX5
NekohDot
wiiquertyuiop
Davros
Telinc1
Schwa
Fernap
RussianMan
imamelia
FuSoYa
DiscoTheBat
Thomas
Isikoro

	AND MUSIC BY
Anikiti
oL7G5poF4c
TomT
Blind Devil
Lazy
Counterfeit
gocha
ElderSubzero
SMW_Hacker17
HertzDevil
Andres
Jimmy
Opposable
Gamma V
Buster Beetle
worldpeace
VecchiaZim
Crispy
Wakana
Wyatt
MercuryPenny
carol
Sui
its_4life
S.N.N.
Tornado
Holy Order Sol
LadiesMan217
Fyre150
6646

	AND GRAPHICS BY
Natsuz2
mikeyk
Schwa
Black Sabbath
SMWEdit
Hinalyte


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;


INCLUDES COVERS OF THE FOLLOWING SONGS:

	"Accidentals"
		By Broadcast
		
	"Swallow at the Hollow" (partial)
		By Panda Bear
		
	"Danse Macabre" (partial)
		By Camille Saint-Saens
	
	"Penny Loafers"
		By Daedelus
		
	"Fugue on a Theme by D. M. Hanlon"
		By Iftkyro
		
	"microchip"
		By Oliver Buckland
	
	"Let's Pop Together"
		By Pop Team Epic

	"Helvetica Standard ~Sono 2~"
		By Nomi Yuuji
		
	"Pettan Pettan Tsurupettan"
		By Silver Forest
		
	"The Greatest Living Show"
		By Toby Fox & Itoki Hana
		
		
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;


SPECIAL THANKS
		for providing these levels
		and letting us remodel them:

	Gbreezesunset	
		"THIS LEVEL SO BAD...."
		"KITAKAMI SWAMP"
		"TOP GAIMDEN AREA"
		"EINS BERG"
		
	Markyjoe1990
		"AUSSIE TOSSIE"
		"UNNAMED BRIDGE"
		(he also made the feather graphic)
		
		
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;











































<3