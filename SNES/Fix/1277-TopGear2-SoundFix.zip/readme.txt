Use with:

File:               Top Gear 2 (USA).sfc (No-Intro)
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              2B88BEE8
MD5:                C9FC87528511770DB888B28A4C506F46