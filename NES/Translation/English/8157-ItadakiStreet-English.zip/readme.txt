Use with:

(No Intro)
File:               Itadaki Street - Watashi no Omise ni Yottette (Japan).nes
BitSize:            2 Mbit
Size (Bytes):       262160
CRC32:              4995D674
MD5:                87DA8028FE2AD9D23A05D0FFB8C3A6FD
SHA1:               26DF0D8221C1CA1DC387F49C84FEB957D71EE071
SHA256:             A7BA02E8B8A513F5B887DFD22F638984F4EE60D2A2E598BFE6B6FFCF2D7534A8
Headerless MD5:     EDFDBE578D7728A4C8C03A7A15A6C21B