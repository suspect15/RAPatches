Use with:

(Redump)
File:  Kaido Racer (Europe) (En,Fr,De,Es,It).iso
CRC32: DE868BFA
MD5:   ad0adf3f0662f7fcd29f6b2391168a8a